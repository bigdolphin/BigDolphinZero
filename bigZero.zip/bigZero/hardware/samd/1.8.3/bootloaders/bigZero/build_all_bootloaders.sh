#!/bin/bash -ex

BOARD_ID=bigZero NAME=samd21_sam_ba_bigZero make clean all

echo Done building bigZero bootloader!

